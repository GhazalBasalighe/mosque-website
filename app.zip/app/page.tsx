"use client";

import { Dropdown } from "flowbite-react";

export default function Home() {
  return (
    <Dropdown label="ئکمه هستممممممم">
      <Dropdown.Item>شزشزشزشز</Dropdown.Item>
      <Dropdown.Item>لام</Dropdown.Item>
      <Dropdown.Item>زشزشز</Dropdown.Item>
      <Dropdown.Item>Siشزشزشزgn out</Dropdown.Item>
    </Dropdown>
  );
}
